<?php
$lang['customers_new']='Pelanggan Baru';
$lang['customers_customer']='Pelanggan';
$lang['customers_update']='Ubah Pelanggan';
$lang['customers_confirm_delete']='Apakah Anda yakin ingin menghapus pelanggan yang dipilih?';
$lang['customers_none_selected']='Anda belum memilih pelanggan untuk dihapus';
$lang['customers_error_adding_updating'] = 'Error menambah / memperbarui pelanggan';
$lang['customers_successful_adding']='Anda telah berhasil menambah pelanggan';
$lang['customers_successful_updating']='Anda telah berhasil memperbarui pelanggan';
$lang['customers_successful_deleted']='Anda telah berhasil menghapus';
$lang['customers_one_or_multiple']='pelanggan';
$lang['customers_cannot_be_deleted']='pelanggan terpilih tidak bisa dihapus; satu atau lebih dari pelanggan yang dipilih memiliki penjualan.';
$lang['customers_basic_information']='Informasi Pelanggan';
$lang['customers_account_number']='Nomor Akun';
$lang['customers_taxable']='Dapat dikenakan pajak';
?>