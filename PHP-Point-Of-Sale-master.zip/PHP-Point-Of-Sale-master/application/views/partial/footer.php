</div>
</div>
<div id="footer"> <?php echo $this->lang->line('common_you_are_using_phppos')?> 10.0.
<?php echo $this->lang->line('common_please_visit_my'); ?> <a href="http://www.phppointofsale.com" target="_blank"><?php echo $this->lang->line('common_website'); ?></a> <?php echo $this->lang->line('common_learn_about_project'); ?>.</div>
</body>
</html>